package VotingSystem.demo.controllers;

import VotingSystem.demo.Service.FaceAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/face")
public class FaceAuthController {

    @Autowired
    private FaceAuthService faceAuthService;

    // Register face → save face embedding
    @PostMapping("/register")
    public ResponseEntity<?> registerFace(@RequestParam Long userId,
                                          @RequestParam("image") MultipartFile image) {
        boolean success = faceAuthService.registerFace(userId, image);
        if (success) {
            return ResponseEntity.ok("Face registered successfully");
        } else {
            return ResponseEntity.badRequest().body("Failed to register face");
        }
    }

    // Face login → match face → return JWT
    @PostMapping("/login")
    public ResponseEntity<?> loginWithFace(@RequestParam("image") MultipartFile image) {
        String token = faceAuthService.loginWithFace(image);
        if (token != null) {
            return ResponseEntity.ok(Map.of("token", token));
        } else {
            return ResponseEntity.status(401).body("Face not recognized");
        }
    }
}
