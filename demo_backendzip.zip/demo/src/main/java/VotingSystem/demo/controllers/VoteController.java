package VotingSystem.demo.controllers;


import VotingSystem.demo.Repository.CandidateRepository;
import VotingSystem.demo.Repository.ElectionRepository;
import VotingSystem.demo.Repository.VoteRepository;
import VotingSystem.demo.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/vote")
public class VoteController {

    @Autowired
    private ElectionRepository electionRepository;
    @Autowired
    private VoteRepository voteRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @PostMapping("/castVote")
    public ResponseEntity<?> castVote(@RequestBody Vote vote) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) auth.getPrincipal();

        Election election = electionRepository.findById(vote.getId()).orElse(null);
        if(election==null || election.getElectionStatus()!= ElectionStatus.ACTIVE){
            return ResponseEntity.status(403).body("Election not active or not found");
        }
        boolean voted=voteRepository.existsByUserIdAndElectionId(user.getId(),election.getId());
        if(voted) return ResponseEntity.badRequest().body("Already voted in this election");

        Candidate candidate = candidateRepository.findById(vote.getId()).orElse(null);
        if(candidate == null || !candidate.getElection().getId().equals(election.getId())) {
            return ResponseEntity.badRequest().body("Invalid candidate for this election");
        }
        Vote v=new Vote(user,election,candidate);
         voteRepository.save(v);
        return ResponseEntity.ok("Vote cast successfully");
    }

}
