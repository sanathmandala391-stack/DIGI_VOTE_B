package VotingSystem.demo.controllers;


import VotingSystem.demo.Repository.CandidateRepository;
import VotingSystem.demo.models.Candidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/candidates")
public class CandidateController {

    @Autowired
    private CandidateRepository candidateRepository;

    @GetMapping("/allcandidates")
    public List<Candidate> getallCandidates(){
        return candidateRepository.findAll();
    }

    @GetMapping("/{electionId}")
    public List<Candidate> getCandidateById(@PathVariable Long electionId){
        return Collections.singletonList(candidateRepository.findById(electionId).orElse(null));
    }


}
