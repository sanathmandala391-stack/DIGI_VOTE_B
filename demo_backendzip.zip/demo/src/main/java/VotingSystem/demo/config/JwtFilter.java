package VotingSystem.demo.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import VotingSystem.demo.models.User;
import VotingSystem.demo.Repository.UserRepository;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

//    @Override
//    protected void doFilterInternal(HttpServletRequest request,
//                                    HttpServletResponse response,
//                                    FilterChain filterChain)
//            throws ServletException, IOException {
//
//        final String authHeader = request.getHeader("Authorization");
//
//        String token = null;
//        Long userId = null;
//
//        // ✅ Extract token
//        if (authHeader != null && authHeader.startsWith("Bearer ")) {
//            token = authHeader.substring(7);
//
//            if (jwtUtil.validateToken(token)) {
//                userId = jwtUtil.extractUserId(token);
//            }
//        }
//
//        // ✅ Set authentication
//        if (userId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//
//            User user = userRepository.findById(userId).orElse(null);
//
//            if (user != null) {
//
//                UsernamePasswordAuthenticationToken authToken =
//                        new UsernamePasswordAuthenticationToken(
//                                user,
//                                null,
//                                List.of(new SimpleGrantedAuthority("USER"))
////                                Collections.emptyList() // roles later
//                        );
//
//                authToken.setDetails(
//                        new WebAuthenticationDetailsSource().buildDetails(request)
//                );
//
//                SecurityContextHolder.getContext().setAuthentication(authToken);
//            }
//        }
//        System.out.println("JWT FILTER RUNNING");
//
//        filterChain.doFilter(request, response);
//    }


@Override
protected void doFilterInternal(HttpServletRequest request,
                                HttpServletResponse response,
                                FilterChain filterChain)
        throws ServletException, IOException {

    final String authHeader = request.getHeader("Authorization");
    String token = null;
    Long userId = null;

    if (authHeader != null && authHeader.startsWith("Bearer ")) {
        token = authHeader.substring(7);
        if (jwtUtil.validateToken(token)) {
            userId = jwtUtil.extractUserId(token);
        }
    }

    if (userId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
        User user = userRepository.findById(userId).orElse(null);

        if (user != null) {
            // Wrap your User as principal and give at least one authority
            UsernamePasswordAuthenticationToken authToken =
                    new UsernamePasswordAuthenticationToken(
                            user, // principal
                            null, // credentials
                            List.of(new SimpleGrantedAuthority("ROLE_USER")) // 🔑 must have at least one role
                    );

            authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authToken);
        }
    }

    System.out.println("JWT FILTER RUNNING");
    filterChain.doFilter(request, response);
}
}