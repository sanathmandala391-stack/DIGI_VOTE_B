package VotingSystem.demo.Repository;

import VotingSystem.demo.models.Candidate;
import jakarta.persistence.Id;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidateRepository extends JpaRepository<Candidate,Long> {
}
