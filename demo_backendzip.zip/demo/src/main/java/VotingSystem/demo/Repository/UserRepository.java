package VotingSystem.demo.Repository;

import VotingSystem.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User,Long> {
    Optional<User> findById(Long userId);
   User findByEmail(String email);
}
