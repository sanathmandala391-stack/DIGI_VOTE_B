package VotingSystem.demo.Service;

import VotingSystem.demo.Repository.UserRepository;
import VotingSystem.demo.config.JwtUtil;
import VotingSystem.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;

@Service
public class FaceAuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // ✅ Register face embedding for a user
    public boolean registerFace(Long userId, MultipartFile image) {
        try {
            User user = userRepository.findById(userId).orElse(null);
            if (user == null) return false;

            // Convert image → face embedding (example, replace with real logic)
            String embedding = encodeFace(image);
            user.setFaceEmbedding(embedding);
            userRepository.save(user);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Face login → compare embeddings → generate JWT
    public String loginWithFace(MultipartFile image) {
        try {
            String embedding = encodeFace(image);

            // Find user with closest matching face
            User matchedUser = userRepository.findAll()
                    .stream()
                    .filter(u -> u.getFaceEmbedding() != null)
                    .filter(u -> compareFaces(embedding, u.getFaceEmbedding()))
                    .findFirst()
                    .orElse(null);

            if (matchedUser != null) {
                return jwtUtil.generateToken(matchedUser.getId());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // 🔹 Placeholder: encode image → string embedding
    private String encodeFace(MultipartFile image) {
        // In real project: convert image → float[] → base64 string
        try {
            return Base64.getEncoder().encodeToString(image.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // 🔹 Placeholder: compare embeddings
    private boolean compareFaces(String embedding1, String embedding2) {
        // Replace with actual similarity/match logic
        return embedding1.equals(embedding2);
    }
}
