package VotingSystem.demo.Service;

import VotingSystem.demo.Repository.UserRepository;
import VotingSystem.demo.config.JwtUtil;
import VotingSystem.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;

    public ResponseEntity<?> UserRegister(User u) {

        User userExists = userRepository.findByEmail(u.getEmail().toLowerCase());

        if (userExists != null) {
            return ResponseEntity
                    .badRequest()
                    .body("User Email Already Taken");
        }

        String hashedPassword = passwordEncoder.encode(u.getPassword());
        u.setPassword(hashedPassword);
        u.setCreatedAt(LocalDateTime.now());
        u.setVerified(false);   // ✅ fixed method

        userRepository.save(u);

        return ResponseEntity.ok("User Registered Successfully");
    }

    //login//
    public ResponseEntity<?> UserLogin(String email, String password) {

        User user = userRepository.findByEmail(email.toLowerCase());

        if (user == null) {
            return ResponseEntity.status(404).body("User not found");
        }

        boolean valid = passwordEncoder.matches(password, user.getPassword());

        if (!valid) {
            return ResponseEntity.ok().body("Invalid Password");
        }
        String token = jwtUtil.generateToken(user.getId());

        return ResponseEntity.ok(Map.of(
                "message:", "Login-Sucessfull",
                "login-Token:", token,
                "User-Email:", user.getEmail(),
                "Role:", user.getRole()
        ));

    }

    public User getUserByEmail(String email) {
     return userRepository.findByEmail(email);

    }
}
