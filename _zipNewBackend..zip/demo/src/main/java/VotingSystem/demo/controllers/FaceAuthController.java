package VotingSystem.demo.controllers;

import VotingSystem.demo.Service.FaceAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/face")
public class FaceAuthController {

    @Autowired
    private FaceAuthService faceAuthService;

    // Register face — receives { userId, descriptor: [128 floats] }
    @PostMapping("/register")
    public ResponseEntity<?> registerFace(@RequestBody Map<String, Object> body) {
        try {
            Long userId = Long.valueOf(body.get("userId").toString());
            String descriptorJson = body.get("descriptor").toString();

            boolean success = faceAuthService.registerFaceDescriptor(userId, descriptorJson);
            if (success) {
                return ResponseEntity.ok("Face registered successfully");
            } else {
                return ResponseEntity.badRequest().body("Failed to register face");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Invalid request: " + e.getMessage());
        }
    }

    // Face login — receives { descriptor: [128 floats] }
    @PostMapping("/login")
    public ResponseEntity<?> loginWithFace(@RequestBody Map<String, Object> body) {
        try {
            String descriptorJson = body.get("descriptor").toString();
            String token = faceAuthService.loginWithDescriptor(descriptorJson);

            if (token != null) {
                return ResponseEntity.ok(Map.of("token", token));
            } else {
                return ResponseEntity.status(401).body("Face not recognized");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Invalid request: " + e.getMessage());
        }
    }
}