package VotingSystem.demo.Service;

import VotingSystem.demo.Repository.UserRepository;
import VotingSystem.demo.config.JwtUtil;
import VotingSystem.demo.models.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FaceAuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // Save the face descriptor (128 floats as JSON string) for a user
    public boolean registerFaceDescriptor(Long userId, String descriptorJson) {
        try {
            User user = userRepository.findById(userId).orElse(null);
            if (user == null) {
                System.out.println("FACE REGISTER >>> user not found: " + userId);
                return false;
            }
            user.setFaceEmbedding(descriptorJson);
            userRepository.save(user);
            System.out.println("FACE REGISTER >>> descriptor saved for userId=" + userId);
            return true;
        } catch (Exception e) {
            System.out.println("FACE REGISTER ERROR: " + e.getMessage());
            return false;
        }
    }

    // Compare uploaded descriptor with all stored ones, return JWT if match found
    public String loginWithDescriptor(String descriptorJson) {
        try {
            double[] uploaded = parseDescriptor(descriptorJson);
            if (uploaded == null) return null;

            List<User> allUsers = userRepository.findAll();

            for (User u : allUsers) {
                if (u.getFaceEmbedding() == null) continue;
                double[] stored = parseDescriptor(u.getFaceEmbedding());
                if (stored == null) continue;

                double distance = euclideanDistance(uploaded, stored);
                System.out.println("FACE LOGIN >>> checking userId=" + u.getId()
                        + " distance=" + distance);

                // face-api.js threshold is typically 0.6
                // Lower distance = more similar faces
                if (distance < 0.6) {
                    String role = u.getRole() != null ? u.getRole().name() : "VOTER";
                    System.out.println("FACE LOGIN >>> MATCHED userId=" + u.getId());
                    return jwtUtil.generateToken(u.getId(), role);
                }
            }

            System.out.println("FACE LOGIN >>> no match found");
            return null;

        } catch (Exception e) {
            System.out.println("FACE LOGIN ERROR: " + e.getMessage());
            return null;
        }
    }

    private double[] parseDescriptor(String json) {
        try {
            double[] arr = objectMapper.readValue(json, double[].class);
            return arr;
        } catch (Exception e) {
            System.out.println("PARSE ERROR: " + e.getMessage());
            return null;
        }
    }

    private double euclideanDistance(double[] a, double[] b) {
        if (a.length != b.length) return Double.MAX_VALUE;
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            double diff = a[i] - b[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
}